﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Projekt.Areas.Identity.Data;
using Projekt.Models;

namespace Projekt.Controllers
{
    public class BookController : Controller
    {
        private readonly ProjektDBContext _context;

        // Konstruktor do wstrzykiwania ProjektDBContext
        public BookController(ProjektDBContext context)
        {
            _context = context;
        }

        // GET: BookController
        public async Task<ActionResult> Index()
        {
            var books = await _context.Book.ToListAsync(); // Pobieranie książek z bazy danych
            return View(books);
        }

        // GET: BookController/Details/5
        public async Task<ActionResult> Details(int id)
        {
            var book = await _context.Book.FirstOrDefaultAsync(x => x.Id == id); // Szukamy książki po ID
            if (book == null)
            {
                return NotFound(); // Jeśli nie znaleziono książki, zwracamy 404
            }
            return View(book);
        }

        // GET: BookController/Create
        //[Authorize]
        public ActionResult Create()
        {
            return View(new Book()); // Zwracamy pusty obiekt do formularza tworzenia
        }

        // POST: BookController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        //[Authorize]
        public async Task<ActionResult> Create(Book book)
        {
            if (ModelState.IsValid)
            {
                _context.Add(book); // Dodanie książki do kontekstu bazy danych
                await _context.SaveChangesAsync(); // Zapisanie zmian do bazy
                return RedirectToAction(nameof(Index)); // Przekierowanie do listy książek
            }
            return View(book); // Jeśli są błędy walidacji, ponownie wyświetlamy formularz
        }

        // GET: BookController/Edit/5
        //[Authorize]
        public async Task<ActionResult> Edit(int id)
        {
            var book = await _context.Book.FirstOrDefaultAsync(x => x.Id == id); // Wyszukiwanie książki do edycji
            if (book == null)
            {
                return NotFound();
            }
            return View(book);
        }

        // POST: BookController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        //[Authorize]
        public async Task<ActionResult> Edit(int id, Book updatedBook)
        {
            if (id != updatedBook.Id)
            {
                return NotFound(); // Jeśli ID w URL i obiekcie nie pasują, zwróć błąd
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(updatedBook); // Aktualizacja książki w bazie
                    await _context.SaveChangesAsync(); // Zapisanie zmian
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookExists(updatedBook.Id)) // Jeśli książka została usunięta w międzyczasie
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index)); // Przekierowanie po pomyślnym zapisaniu zmian
            }
            return View(updatedBook); // Jeśli model jest niepoprawny, zwróć formularz edycji
        }

        // GET: BookController/Delete/5
        //[Authorize]
        public async Task<ActionResult> Delete(int id)
        {
            var book = await _context.Book.FirstOrDefaultAsync(x => x.Id == id); // Pobieranie książki do usunięcia
            if (book == null)
            {
                return NotFound();
            }
            return View(book);
        }

        // POST: BookController/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        //[Authorize]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            var book = await _context.Book.FirstOrDefaultAsync(x => x.Id == id); // Pobieranie książki do usunięcia
            if (book == null)
            {
                return NotFound();
            }

            _context.Book.Remove(book); // Usuwanie książki z kontekstu bazy danych
            await _context.SaveChangesAsync(); // Zapisanie zmian w bazie
            return RedirectToAction(nameof(Index)); // Przekierowanie do listy książek
        }

        private bool BookExists(int id)
        {
            return _context.Book.Any(e => e.Id == id); // Sprawdzanie, czy książka istnieje w bazie
        }
    }
}